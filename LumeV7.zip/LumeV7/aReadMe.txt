!! PLEASE READ CAREFULLY THE INFORMATION BELOW !!

------------------------
IF LUMIER DOESN'T OPEN ->
------------------------
 
You must download Microsoft Visual C++ Redistributable & .NET 8.0 to make Lumier run properly.
If Lumier doesn't open for you, that's because you did not download the required dependencies.

Open these links below to download them:

https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170
https://dotnet.microsoft.com/en-us/download/dotnet/8.0

Microsoft Visual C++ Redistributable is optional as this zip file already provides it, it is still recommended to download it.

If Lumier does not open at all after having those dependencies installed, run .NET 8.0 installer then select the repair option. That is a problem with .NET

-------------------------------------
IF YOU CAN'T FIND DOWNLOADED COPIES ->
-------------------------------------

Simply run Lumier as an admin and that should fix the issue.
If you still can't find the downloaded .rbxl place within the workspace folder, simply search "place (ID)" into the windows search bar.








